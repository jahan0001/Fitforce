import { Platform } from 'react-native';
import Constants from 'expo-constants';

const API_PORT = 4000;

/**
 * Figures out where the shared data server is, without hardcoding an IP.
 * On web, the browser's own address bar already has the right LAN IP (or
 * "localhost") — reuse it. On native running through the Expo dev server
 * (Expo Go / dev client), Constants exposes the host:port the JS bundle
 * was loaded from, which lives on the same machine as the data server;
 * swap its port for the data server's.
 *
 * A standalone build (installed APK) has no dev server connection, so
 * hostUri is unavailable there — it falls back to `extra.apiHost` from
 * app.json, which must point at the LAN IP of the machine running
 * server/api-server.js.
 */
function resolveApiBase(): string {
  if (Platform.OS === 'web' && typeof window !== 'undefined' && window.location?.hostname) {
    return `http://${window.location.hostname}:${API_PORT}`;
  }
  const hostUri =
    Constants.expoConfig?.hostUri ??
    (Constants as any).expoGoConfig?.hostUri ??
    (Constants as any).manifest2?.extra?.expoClient?.hostUri;
  const fallbackHost = Constants.expoConfig?.extra?.apiHost ?? 'localhost';
  const host = hostUri ? String(hostUri).split(':')[0] : fallbackHost;
  return `http://${host}:${API_PORT}`;
}

export const API_BASE = resolveApiBase();
