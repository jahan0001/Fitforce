import { Platform } from 'react-native';
import Constants from 'expo-constants';

const API_PORT = 4000;

/**
 * Figures out where the shared data server is, without hardcoding an IP.
 * On web, the browser's own address bar already has the right LAN IP (or
 * "localhost") — reuse it. On native (Expo Go), Constants exposes the
 * host:port the JS bundle was loaded from, which lives on the same
 * machine as the data server; swap its port for the data server's.
 */
function resolveApiBase(): string {
  if (Platform.OS === 'web' && typeof window !== 'undefined' && window.location?.hostname) {
    return `http://${window.location.hostname}:${API_PORT}`;
  }
  const hostUri =
    Constants.expoConfig?.hostUri ??
    (Constants as any).expoGoConfig?.hostUri ??
    (Constants as any).manifest2?.extra?.expoClient?.hostUri;
  const host = hostUri ? String(hostUri).split(':')[0] : 'localhost';
  return `http://${host}:${API_PORT}`;
}

export const API_BASE = resolveApiBase();
