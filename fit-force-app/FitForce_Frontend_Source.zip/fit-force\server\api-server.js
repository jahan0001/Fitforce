// Shared data server for Fit Force.
//
// The app used to store everything (users, soldiers, messages, ...) in
// per-device AsyncStorage, so a soldier registering on a phone was
// invisible to the Adjutant approving accounts on a laptop, and messages
// never reached anyone on a different device. This server holds the one
// shared copy of that data so every device reads and writes the same
// state, over the same LAN the Expo dev server already uses.
//
// It exposes a tiny key/value API that mirrors AsyncStorage's own
// getItem/setItem shape, so lib/storage.ts only had to change how it reads
// and writes a value, not the data model itself. It also exposes a small
// file upload/download API so Reports can carry a real PDF/DOC attachment
// instead of just a filename label.

const http = require('http');
const fs = require('fs');
const path = require('path');

const {
  SEED_USERS, SEED_SOLDIERS, SEED_PT_PLANS, SEED_IPFT_RESULTS,
  SEED_IPFT_SCHEDULE, SEED_NOTIFICATIONS, SEED_REPORTS,
} = require('./seed-data');
const { renderPlanPdf } = require('./pdf');

const PORT = 4000;
const DATA_FILE = path.join(__dirname, 'data-store.json');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const MAX_UPLOAD_BYTES = 15 * 1024 * 1024; // 15MB, comfortably covers a scanned PDF/DOC

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const INITIAL_STORE = {
  'fitforce:users': SEED_USERS,
  'fitforce:soldiers': SEED_SOLDIERS,
  'fitforce:pt_plans': SEED_PT_PLANS,
  'fitforce:ipft_results': SEED_IPFT_RESULTS,
  'fitforce:ipft_schedule': SEED_IPFT_SCHEDULE,
  'fitforce:notifications': SEED_NOTIFICATIONS,
  'fitforce:messages': [],
  'fitforce:reports': [],
};

function loadStore() {
  if (fs.existsSync(DATA_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch (e) {
      console.error('Failed to parse data-store.json, reseeding.', e);
    }
  }
  fs.writeFileSync(DATA_FILE, JSON.stringify(INITIAL_STORE, null, 2));
  return { ...INITIAL_STORE };
}

let store = loadStore();
let saveTimer = null;

function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    fs.writeFile(DATA_FILE, JSON.stringify(store, null, 2), err => {
      if (err) console.error('Failed to persist data-store.json', err);
    });
  }, 150);
}

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
}

function readJsonBody(req, maxBytes) {
  return new Promise((resolve, reject) => {
    let body = '';
    let bytes = 0;
    req.on('data', chunk => {
      bytes += chunk.length;
      if (maxBytes && bytes > maxBytes) {
        reject(new Error('Payload too large'));
        req.destroy();
        return;
      }
      body += chunk;
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : null);
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  setCors(res);

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const url = new URL(req.url, `http://${req.headers.host}`);

  if (url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true }));
    return;
  }

  // ── File upload: client sends { name, mimeType, base64 } as JSON ──
  if (req.method === 'POST' && url.pathname === '/upload') {
    try {
      const payload = await readJsonBody(req, MAX_UPLOAD_BYTES * 1.4); // base64 inflates ~33%
      if (!payload || !payload.base64 || !payload.name) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'name and base64 are required' }));
        return;
      }
      const buffer = Buffer.from(payload.base64, 'base64');
      if (buffer.length > MAX_UPLOAD_BYTES) {
        res.writeHead(413, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'File too large (max 15MB)' }));
        return;
      }
      const safeName = String(payload.name).replace(/[^a-zA-Z0-9_.-]/g, '_').slice(-100);
      const storedName = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}-${safeName}`;
      fs.writeFileSync(path.join(UPLOAD_DIR, storedName), buffer);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        url: `/files/${storedName}`,
        name: safeName,
        mimeType: payload.mimeType || 'application/octet-stream',
        size: buffer.length,
      }));
    } catch (e) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Upload failed' }));
    }
    return;
  }

  // ── Generate a PT plan PDF: client sends the plan JSON, gets back a URL ──
  if (req.method === 'POST' && url.pathname === '/generate-plan-pdf') {
    try {
      const plan = await readJsonBody(req, 2 * 1024 * 1024);
      if (!plan || !plan.title) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'A plan object is required' }));
        return;
      }
      const buffer = await renderPlanPdf(plan);
      const safeName = `${String(plan.title).replace(/[^a-zA-Z0-9_.-]/g, '_').slice(0, 60)}.pdf`;
      const storedName = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}-${safeName}`;
      fs.writeFileSync(path.join(UPLOAD_DIR, storedName), buffer);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ url: `/files/${storedName}`, name: safeName, mimeType: 'application/pdf', size: buffer.length }));
    } catch (e) {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Could not generate PDF' }));
    }
    return;
  }

  // ── File download ──
  const fileMatch = url.pathname.match(/^\/files\/([^/]+)$/);
  if (req.method === 'GET' && fileMatch) {
    const storedName = decodeURIComponent(fileMatch[1]);
    const filePath = path.join(UPLOAD_DIR, storedName);
    if (!filePath.startsWith(UPLOAD_DIR) || !fs.existsSync(filePath)) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Not found' }));
      return;
    }
    const displayName = storedName.replace(/^[a-z0-9]+-[a-z0-9]+-/i, '');
    const forceDownload = url.searchParams.get('download') === '1';
    const contentType = displayName.toLowerCase().endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': contentType,
      'Content-Disposition': `${forceDownload ? 'attachment' : 'inline'}; filename="${displayName}"`,
    });
    fs.createReadStream(filePath).pipe(res);
    return;
  }

  // ── Key/value store (everything else) ──
  const kvMatch = url.pathname.match(/^\/kv\/(.+)$/);
  if (!kvMatch) {
    res.writeHead(404, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Not found' }));
    return;
  }

  const key = decodeURIComponent(kvMatch[1]);

  if (req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(store[key] ?? null));
    return;
  }

  if (req.method === 'PUT') {
    try {
      const parsed = await readJsonBody(req);
      store[key] = parsed;
      persist();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
    } catch (e) {
      res.writeHead(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid JSON body' }));
    }
    return;
  }

  res.writeHead(405, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'Method not allowed' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Fit Force data server listening on http://0.0.0.0:${PORT}`);
  console.log(`Data file: ${DATA_FILE}`);
  console.log(`Uploads dir: ${UPLOAD_DIR}`);
});
