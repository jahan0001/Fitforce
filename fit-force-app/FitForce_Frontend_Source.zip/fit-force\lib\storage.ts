import { API_BASE } from './api';
import type { User, Soldier, PTPlan, IPFTResult, IPFTSchedule, Notification, Report, Message } from './types';

const KEYS = {
  USERS: 'fitforce:users',
  SOLDIERS: 'fitforce:soldiers',
  PT_PLANS: 'fitforce:pt_plans',
  IPFT_RESULTS: 'fitforce:ipft_results',
  IPFT_SCHEDULE: 'fitforce:ipft_schedule',
  NOTIFICATIONS: 'fitforce:notifications',
  MESSAGES: 'fitforce:messages',
  REPORTS: 'fitforce:reports',
};

/**
 * All app data now lives on a small shared server (see server/api-server.js)
 * instead of per-device AsyncStorage, so every device sees the same users,
 * soldiers, messages, notifications and reports. The server seeds itself on
 * first run, so there is nothing left for the client to initialize.
 */
export async function initStorage(): Promise<void> {}

async function getItem<T>(key: string): Promise<T | null> {
  const res = await fetch(`${API_BASE}/kv/${encodeURIComponent(key)}`);
  if (!res.ok) return null;
  return res.json();
}

async function setItem<T>(key: string, value: T): Promise<void> {
  await fetch(`${API_BASE}/kv/${encodeURIComponent(key)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(value),
  });
}

async function getAll<T>(key: string): Promise<T[]> {
  const data = await getItem<T[]>(key);
  return data ?? [];
}

async function setAll<T>(key: string, data: T[]): Promise<void> {
  await setItem(key, data);
}

// ── Users ────────────────────────────────────────────────
export async function getUsers(): Promise<User[]> { return getAll<User>(KEYS.USERS); }

export async function findUserByEmail(email: string): Promise<User | null> {
  const users = await getUsers();
  return users.find(u => u.email.toLowerCase() === email.toLowerCase()) ?? null;
}

export async function addUser(user: User): Promise<void> {
  const users = await getUsers();
  users.push(user);
  await setAll(KEYS.USERS, users);
}

export async function updateUser(id: string, updates: Partial<User>): Promise<void> {
  const users = await getUsers();
  const idx = users.findIndex(u => u.id === id);
  if (idx >= 0) {
    users[idx] = { ...users[idx], ...updates };
    await setAll(KEYS.USERS, users);
  }
}

export async function deleteUser(id: string): Promise<void> {
  const users = await getUsers();
  await setAll(KEYS.USERS, users.filter(u => u.id !== id));
}

// ── Soldiers ──────────────────────────────────────────────
export async function getSoldiers(): Promise<Soldier[]> { return getAll<Soldier>(KEYS.SOLDIERS); }

export async function getSoldiersByCompany(company: string): Promise<Soldier[]> {
  const soldiers = await getSoldiers();
  return soldiers.filter(s => s.company === company);
}

export async function getSoldierById(id: string): Promise<Soldier | null> {
  const soldiers = await getSoldiers();
  return soldiers.find(s => s.id === id) ?? null;
}

export async function updateSoldier(id: string, updates: Partial<Soldier>): Promise<void> {
  const soldiers = await getSoldiers();
  const idx = soldiers.findIndex(s => s.id === id);
  if (idx >= 0) {
    soldiers[idx] = { ...soldiers[idx], ...updates };
    await setAll(KEYS.SOLDIERS, soldiers);
  }
}

export async function deleteSoldier(id: string): Promise<void> {
  const soldiers = await getSoldiers();
  await setAll(KEYS.SOLDIERS, soldiers.filter(s => s.id !== id));
}

export async function addSoldier(soldier: Soldier): Promise<void> {
  const soldiers = await getSoldiers();
  soldiers.push(soldier);
  await setAll(KEYS.SOLDIERS, soldiers);
}

// ── PT Plans ──────────────────────────────────────────────
export async function getPTPlans(): Promise<PTPlan[]> { return getAll<PTPlan>(KEYS.PT_PLANS); }

export async function addPTPlan(plan: PTPlan): Promise<void> {
  const plans = await getPTPlans();
  plans.unshift(plan);
  await setAll(KEYS.PT_PLANS, plans);
}

// ── IPFT Results ──────────────────────────────────────────
export async function getIPFTResults(): Promise<IPFTResult[]> { return getAll<IPFTResult>(KEYS.IPFT_RESULTS); }

export async function getIPFTResultsBySoldier(soldierId: string): Promise<IPFTResult[]> {
  const results = await getIPFTResults();
  return results.filter(r => r.soldierId === soldierId).sort((a, b) => b.date.localeCompare(a.date));
}

export async function addIPFTResult(result: IPFTResult): Promise<void> {
  const results = await getIPFTResults();
  results.unshift(result);
  await setAll(KEYS.IPFT_RESULTS, results);
}

// ── IPFT Schedule ─────────────────────────────────────────
export async function getIPFTSchedule(): Promise<IPFTSchedule | null> {
  return getItem<IPFTSchedule>(KEYS.IPFT_SCHEDULE);
}

export async function saveIPFTSchedule(schedule: IPFTSchedule): Promise<void> {
  await setItem(KEYS.IPFT_SCHEDULE, schedule);
}

// ── Notifications ─────────────────────────────────────────
export async function getNotifications(): Promise<Notification[]> { return getAll<Notification>(KEYS.NOTIFICATIONS); }

export async function addNotification(notif: Notification): Promise<void> {
  const notifs = await getNotifications();
  notifs.unshift(notif);
  await setAll(KEYS.NOTIFICATIONS, notifs);
}

export async function markNotificationRead(id: string): Promise<void> {
  const notifs = await getNotifications();
  const idx = notifs.findIndex(n => n.id === id);
  if (idx >= 0) { notifs[idx].read = true; await setAll(KEYS.NOTIFICATIONS, notifs); }
}

export async function markAllNotificationsRead(): Promise<void> {
  const notifs = await getNotifications();
  notifs.forEach(n => { n.read = true; });
  await setAll(KEYS.NOTIFICATIONS, notifs);
}

// ── Messages ──────────────────────────────────────────────
export async function getMessages(): Promise<Message[]> { return getAll<Message>(KEYS.MESSAGES); }

export async function addMessage(msg: Message): Promise<void> {
  const msgs = await getMessages();
  msgs.unshift(msg);
  await setAll(KEYS.MESSAGES, msgs);
}

export async function markMessageRead(id: string): Promise<void> {
  const msgs = await getMessages();
  const idx = msgs.findIndex(m => m.id === id);
  if (idx >= 0) { msgs[idx].read = true; await setAll(KEYS.MESSAGES, msgs); }
}

// ── Reports ───────────────────────────────────────────────
export async function getReports(): Promise<Report[]> { return getAll<Report>(KEYS.REPORTS); }

export async function addReport(report: Report): Promise<void> {
  const reports = await getReports();
  reports.unshift(report);
  await setAll(KEYS.REPORTS, reports);
}

export async function markReportRead(id: string): Promise<void> {
  const reports = await getReports();
  const idx = reports.findIndex(r => r.id === id);
  if (idx >= 0) { reports[idx].read = true; await setAll(KEYS.REPORTS, reports); }
}

// ── Helpers ───────────────────────────────────────────────
export function calcBMI(weight: number, height: number): number {
  const h = height / 100;
  return Math.round((weight / (h * h)) * 10) / 10;
}

/** Computes age in whole years from a "YYYY-MM-DD" date of birth, as of today. */
export function calcAge(dateOfBirth: string): number {
  const dob = new Date(dateOfBirth);
  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const monthDiff = today.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
    age--;
  }
  return age;
}

export function genId(): string {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
}
